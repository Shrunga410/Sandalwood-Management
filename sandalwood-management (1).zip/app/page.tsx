"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Chatbot } from "./components/chatbot"

interface UserData {
  fullName: string
  aadhaarNumber: string
  fatherName: string
  landAddress: string
  residentialAddress: string
  phoneNumber: string
}

export default function LoginPage() {
  const [userData, setUserData] = useState<UserData>({
    fullName: "",
    aadhaarNumber: "",
    fatherName: "",
    landAddress: "",
    residentialAddress: "",
    phoneNumber: "",
  })
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const { toast } = useToast()
  const [showOTPVerification, setShowOTPVerification] = useState(false)
  const [otp, setOtp] = useState("")
  const [generatedOTP, setGeneratedOTP] = useState("")

  useEffect(() => {
    const savedUser = localStorage.getItem("sandalwood_user")
    if (savedUser) {
      setIsLoggedIn(true)
    }
  }, [])

  const handleInputChange = (field: keyof UserData, value: string) => {
    setUserData((prev) => ({ ...prev, [field]: value }))
  }

  const handleOTPVerification = () => {
    if (otp === generatedOTP) {
      // Save to localStorage
      localStorage.setItem("sandalwood_user", JSON.stringify(userData))

      toast({
        title: "Success",
        description: "OTP verified successfully! Redirecting to dashboard...",
      })

      setTimeout(() => {
        setIsLoggedIn(true)
      }, 1000)
    } else {
      toast({
        title: "Error",
        description: "Invalid OTP. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate required fields
    if (
      !userData.fullName ||
      !userData.aadhaarNumber ||
      !userData.fatherName ||
      !userData.landAddress ||
      !userData.residentialAddress ||
      !userData.phoneNumber
    ) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    // Validate Aadhaar number (12 digits)
    if (!/^\d{12}$/.test(userData.aadhaarNumber)) {
      toast({
        title: "Error",
        description: "Aadhaar number must be 12 digits",
        variant: "destructive",
      })
      return
    }

    // Validate phone number (10 digits)
    if (!/^\d{10}$/.test(userData.phoneNumber)) {
      toast({
        title: "Error",
        description: "Mobile number must be 10 digits",
        variant: "destructive",
      })
      return
    }

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString()
    setGeneratedOTP(otp)

    toast({
      title: "OTP Sent",
      description: `OTP sent to +91-${userData.phoneNumber}`,
    })

    setShowOTPVerification(true)
  }

  if (isLoggedIn) {
    return <Dashboard />
  }

  if (showOTPVerification) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 flex items-center justify-center p-4">
        {/* Government Header */}
        <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-orange-500 via-white to-green-500 h-2"></div>

        <Card className="w-full max-w-md border-2 border-orange-200">
          <CardHeader className="text-center bg-gradient-to-r from-orange-100 to-green-100 rounded-t-lg">
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-green-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">🌳</span>
              </div>
            </div>
            <CardTitle className="text-xl font-bold text-gray-800">OTP Verification</CardTitle>
            <CardDescription>Enter the 6-digit OTP sent to +91-{userData.phoneNumber}</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="otp">Enter OTP</Label>
                <Input
                  id="otp"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="Enter 6-digit OTP"
                  maxLength={6}
                  className="text-center text-lg tracking-widest"
                />
              </div>
              <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded-lg">
                <strong>Demo OTP:</strong> {generatedOTP}
              </div>
              <Button
                onClick={handleOTPVerification}
                className="w-full bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700"
              >
                Verify OTP
              </Button>
              <Button variant="outline" onClick={() => setShowOTPVerification(false)} className="w-full">
                Back to Login
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 flex items-center justify-center p-4">
      {/* Government Header */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-orange-500 via-white to-green-500 h-2"></div>

      {/* Government Emblem Style Header */}
      <div className="absolute top-4 left-0 right-0 flex justify-center">
        <div className="bg-white rounded-full p-4 shadow-lg border-2 border-orange-200">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-green-600 rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-lg">🌳</span>
          </div>
        </div>
      </div>

      <Card className="w-full max-w-2xl mt-16 border-2 border-orange-200 shadow-xl">
        <CardHeader className="text-center bg-gradient-to-r from-orange-100 to-green-100 rounded-t-lg">
          <CardTitle className="text-2xl font-bold text-gray-800">Government of India</CardTitle>
          <CardTitle className="text-xl font-semibold text-green-700 mt-2">
            🌳 Sandalwood Tree Management System
          </CardTitle>
          <CardDescription className="text-gray-600 mt-2">
            Ministry of Environment, Forest and Climate Change
          </CardDescription>
          <CardDescription className="text-sm text-gray-500">
            Please enter your details to access the system
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  value={userData.fullName}
                  onChange={(e) => handleInputChange("fullName", e.target.value)}
                  placeholder="Enter your full name"
                  required
                  className="border-orange-200 focus:border-green-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="aadhaarNumber">Aadhaar Number *</Label>
                <Input
                  id="aadhaarNumber"
                  value={userData.aadhaarNumber}
                  onChange={(e) => handleInputChange("aadhaarNumber", e.target.value)}
                  placeholder="12-digit Aadhaar number"
                  maxLength={12}
                  required
                  className="border-orange-200 focus:border-green-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fatherName">Father's Name *</Label>
                <Input
                  id="fatherName"
                  value={userData.fatherName}
                  onChange={(e) => handleInputChange("fatherName", e.target.value)}
                  placeholder="Enter father's name"
                  required
                  className="border-orange-200 focus:border-green-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phoneNumber">Mobile Number *</Label>
                <Input
                  id="phoneNumber"
                  value={userData.phoneNumber}
                  onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                  placeholder="10-digit mobile number"
                  maxLength={10}
                  required
                  className="border-orange-200 focus:border-green-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="landAddress">Land Address *</Label>
              <Textarea
                id="landAddress"
                value={userData.landAddress}
                onChange={(e) => handleInputChange("landAddress", e.target.value)}
                placeholder="Enter land address where trees are located"
                required
                className="border-orange-200 focus:border-green-500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="residentialAddress">Residential Address *</Label>
              <Textarea
                id="residentialAddress"
                value={userData.residentialAddress}
                onChange={(e) => handleInputChange("residentialAddress", e.target.value)}
                placeholder="Enter your residential address"
                required
                className="border-orange-200 focus:border-green-500"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700 text-white font-semibold py-3"
            >
              Send OTP & Continue
            </Button>
          </form>

          <div className="mt-6 text-center text-xs text-gray-500 border-t pt-4">
            <p>© 2024 Government of India. All rights reserved.</p>
            <p>This is a secure government portal. Your data is protected.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function Dashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [userData, setUserData] = useState<UserData | null>(null)
  const [requests, setRequests] = useState<any[]>([])

  useEffect(() => {
    const savedUser = localStorage.getItem("sandalwood_user")
    const savedRequests = localStorage.getItem("sandalwood_requests")

    if (savedUser) {
      setUserData(JSON.parse(savedUser))
    }
    if (savedRequests) {
      setRequests(JSON.parse(savedRequests))
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("sandalwood_user")
    window.location.reload()
  }

  const getStats = () => {
    const totalRequests = requests.length
    const approvedTrees = requests.reduce((sum, req) => sum + (req.approvedTrees || 0), 0)
    const rejectedTrees = requests.reduce((sum, req) => sum + (req.rejectedTrees || 0), 0)

    return { totalRequests, approvedTrees, rejectedTrees }
  }

  const stats = getStats()

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50">
      {/* Government Header */}
      <div className="bg-gradient-to-r from-orange-500 via-white to-green-500 h-1"></div>
      <header className="bg-white border-b-2 border-orange-200 shadow-sm">
        <div className="max-w-6xl mx-auto p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-green-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">🌳</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">Government of India</h1>
                <p className="text-sm text-gray-600">Sandalwood Management System</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-800">Welcome, {userData?.fullName}</p>
                <p className="text-xs text-gray-500">Ministry of Environment</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="border-orange-200 text-orange-600 hover:bg-orange-50 bg-transparent"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-gradient-to-r from-orange-100 to-green-100 border-b border-orange-200">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === "dashboard"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-600 hover:text-gray-800"
              }`}
            >
              📊 Dashboard
            </button>
            <button
              onClick={() => setActiveTab("new-request")}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === "new-request"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-600 hover:text-gray-800"
              }`}
            >
              ➕ New Request
            </button>
            <button
              onClick={() => setActiveTab("track-order")}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === "track-order"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-600 hover:text-gray-800"
              }`}
            >
              🔍 Track Orders
            </button>
            <button
              onClick={() => setActiveTab("profile")}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === "profile"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-600 hover:text-gray-800"
              }`}
            >
              👤 Profile
            </button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-6xl mx-auto p-4">
        {activeTab === "dashboard" && <DashboardContent stats={stats} />}
        {activeTab === "new-request" && <NewRequestTab requests={requests} setRequests={setRequests} />}
        {activeTab === "track-order" && <TrackOrderTab requests={requests} />}
        {activeTab === "profile" && <ProfileTab userData={userData} setUserData={setUserData} />}
      </main>
      {/* Add this right before the closing </div> of the Dashboard function */}
      <Chatbot activeTab={activeTab} userData={userData} requests={requests} />
    </div>
  )
}

function DashboardContent({ stats }: { stats: any }) {
  // Mock sandalwood rates - in real app, this would come from an API
  const sandalwoodRates = {
    currentRate: 8500,
    previousRate: 8200,
    trend: "up",
    lastUpdated: new Date().toLocaleDateString(),
    ratePerKg: 8500,
    ratePerTon: 8500000,
  }

  const rateChange = sandalwoodRates.currentRate - sandalwoodRates.previousRate
  const rateChangePercent = ((rateChange / sandalwoodRates.previousRate) * 100).toFixed(2)

  return (
    <div className="space-y-6">
      {/* Government Header */}
      <div className="bg-gradient-to-r from-orange-100 to-green-100 p-4 rounded-lg border-l-4 border-orange-500">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Dashboard Overview</h2>
        <p className="text-gray-600">Ministry of Environment, Forest and Climate Change</p>
        <p className="text-sm text-gray-500">Sandalwood Tree Management Portal</p>
      </div>

      {/* Sandalwood Rate Card */}
      <Card className="border-2 border-orange-200 bg-gradient-to-r from-orange-50 to-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <span className="text-2xl">💰</span>
            Current Sandalwood Market Rate
          </CardTitle>
          <CardDescription>Official rates as per Government guidelines</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-white rounded-lg border border-orange-200">
              <div className="text-3xl font-bold text-green-600">₹{sandalwoodRates.ratePerKg.toLocaleString()}</div>
              <div className="text-sm text-gray-600">Per Kilogram</div>
              <div
                className={`text-xs mt-1 flex items-center justify-center gap-1 ${
                  sandalwoodRates.trend === "up" ? "text-green-600" : "text-red-600"
                }`}
              >
                <span>{sandalwoodRates.trend === "up" ? "↗️" : "↘️"}</span>
                {rateChangePercent}% from last month
              </div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border border-orange-200">
              <div className="text-2xl font-bold text-blue-600">
                ₹{(sandalwoodRates.ratePerTon / 1000000).toFixed(1)}L
              </div>
              <div className="text-sm text-gray-600">Per Ton</div>
              <div className="text-xs text-gray-500 mt-1">Rate Change: +₹{rateChange}</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border border-orange-200">
              <div className="text-lg font-bold text-orange-600">Updated</div>
              <div className="text-sm text-gray-600">{sandalwoodRates.lastUpdated}</div>
              <div className="text-xs text-gray-500 mt-1">Next update: Tomorrow</div>
            </div>
          </div>
          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> Rates are subject to market conditions and government regulations. For official
              transactions, please verify with local forest department.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Existing Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-orange-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
            <span className="text-2xl">📝</span>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalRequests}</div>
            <p className="text-xs text-muted-foreground">Requests submitted</p>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trees Approved</CardTitle>
            <span className="text-2xl">✅</span>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.approvedTrees}</div>
            <p className="text-xs text-muted-foreground">Trees meeting criteria</p>
          </CardContent>
        </Card>

        <Card className="border-red-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trees Rejected</CardTitle>
            <span className="text-2xl">❌</span>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.rejectedTrees}</div>
            <p className="text-xs text-muted-foreground">Trees not meeting criteria</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-orange-200">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4">
          <Button className="bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700">
            ➕ Submit New Request
          </Button>
          <Button variant="outline" className="border-orange-200 hover:bg-orange-50 bg-transparent">
            🔍 Track Your Orders
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

function NewRequestTab({ requests, setRequests }: { requests: any[]; setRequests: (requests: any[]) => void }) {
  const [formData, setFormData] = useState({
    numberOfTrees: "",
    treeDetails: [{ height: "", girth: "", image: null as File | null }],
  })
  const [validationResult, setValidationResult] = useState<any>(null)
  const { toast } = useToast()

  const handleTreeCountChange = (count: string) => {
    const numTrees = Number.parseInt(count) || 0
    const newTreeDetails = Array.from(
      { length: numTrees },
      (_, i) => formData.treeDetails[i] || { height: "", girth: "", image: null },
    )

    setFormData({
      numberOfTrees: count,
      treeDetails: newTreeDetails,
    })
  }

  const handleTreeDetailChange = (index: number, field: string, value: any) => {
    const newTreeDetails = [...formData.treeDetails]
    newTreeDetails[index] = { ...newTreeDetails[index], [field]: value }
    setFormData({ ...formData, treeDetails: newTreeDetails })
  }

  const validateTrees = () => {
    const results = formData.treeDetails.map((tree, index) => {
      const height = Number.parseFloat(tree.height) || 0
      const girth = Number.parseFloat(tree.girth) || 0
      const meetsHeightCriteria = height > 6
      const meetsGirthCriteria = girth > 1.5
      const meetsCriteria = meetsHeightCriteria && meetsGirthCriteria

      return {
        treeIndex: index + 1,
        height,
        girth,
        meetsHeightCriteria,
        meetsGirthCriteria,
        meetsCriteria,
      }
    })

    const approvedCount = results.filter((r) => r.meetsCriteria).length
    const rejectedCount = results.length - approvedCount

    setValidationResult({
      results,
      approvedCount,
      rejectedCount,
      totalTrees: results.length,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.numberOfTrees || formData.treeDetails.some((tree) => !tree.height || !tree.girth)) {
      toast({
        title: "Error",
        description: "Please fill in all tree details",
        variant: "destructive",
      })
      return
    }

    validateTrees()

    // Save request
    const newRequest = {
      id: Date.now(),
      date: new Date().toLocaleDateString(),
      numberOfTrees: Number.parseInt(formData.numberOfTrees),
      treeDetails: formData.treeDetails,
      approvedTrees: validationResult?.approvedCount || 0,
      rejectedTrees: validationResult?.rejectedCount || 0,
      status: "Under Review",
    }

    const updatedRequests = [...requests, newRequest]
    setRequests(updatedRequests)
    localStorage.setItem("sandalwood_requests", JSON.stringify(updatedRequests))

    toast({
      title: "Success",
      description: "Request submitted successfully!",
    })

    // Reset form
    setFormData({
      numberOfTrees: "",
      treeDetails: [{ height: "", girth: "", image: null }],
    })
    setValidationResult(null)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">New Tree Request</h2>
        <p className="text-gray-600">Submit details for tree evaluation</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tree Details</CardTitle>
          <CardDescription>
            Criteria: Height {">"} 6 feet & Girth {">"} 1.5 feet
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="numberOfTrees">Number of Trees</Label>
              <Input
                id="numberOfTrees"
                type="number"
                min="1"
                max="50"
                value={formData.numberOfTrees}
                onChange={(e) => handleTreeCountChange(e.target.value)}
                placeholder="Enter number of trees"
                className="max-w-xs"
              />
            </div>

            {formData.treeDetails.map((tree, index) => (
              <Card key={index} className="p-4">
                <h4 className="font-medium mb-4">Tree {index + 1}</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Height (feet)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={tree.height}
                      onChange={(e) => handleTreeDetailChange(index, "height", e.target.value)}
                      placeholder="e.g., 7.5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Girth (feet)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={tree.girth}
                      onChange={(e) => handleTreeDetailChange(index, "girth", e.target.value)}
                      placeholder="e.g., 2.0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Tree Image</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleTreeDetailChange(index, "image", e.target.files?.[0] || null)}
                    />
                  </div>
                </div>
              </Card>
            ))}

            <div className="flex gap-4">
              <Button type="button" onClick={validateTrees} variant="outline">
                Validate Trees
              </Button>
              <Button type="submit" className="bg-green-600 hover:bg-green-700">
                Submit Request
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {validationResult && (
        <Card>
          <CardHeader>
            <CardTitle>Validation Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{validationResult.totalTrees}</div>
                <div className="text-sm text-blue-600">Total Trees</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{validationResult.approvedCount}</div>
                <div className="text-sm text-green-600">Meet Criteria</div>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{validationResult.rejectedCount}</div>
                <div className="text-sm text-red-600">Don't Meet Criteria</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Individual Tree Results:</h4>
              {validationResult.results.map((result: any) => (
                <div
                  key={result.treeIndex}
                  className={`p-3 rounded-lg border ${
                    result.meetsCriteria ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Tree {result.treeIndex}</span>
                    <span
                      className={`px-2 py-1 rounded text-sm ${
                        result.meetsCriteria ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      {result.meetsCriteria ? "✅ Approved" : "❌ Rejected"}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    Height: {result.height}ft {result.meetsHeightCriteria ? "✅" : "❌"} | Girth: {result.girth}ft{" "}
                    {result.meetsGirthCriteria ? "✅" : "❌"}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function TrackOrderTab({ requests }: { requests: any[] }) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Track Your Orders</h2>
        <p className="text-gray-600">View all your submitted requests and their status</p>
      </div>

      {requests.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <div className="text-gray-500 mb-4">📝</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No requests yet</h3>
            <p className="text-gray-600">Submit your first tree request to see it here</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {requests.map((request) => (
            <Card key={request.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">Request #{request.id}</CardTitle>
                    <CardDescription>Submitted on {request.date}</CardDescription>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium ${
                      request.status === "Approved"
                        ? "bg-green-100 text-green-800"
                        : request.status === "Rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-yellow-100 text-yellow-800"
                    }`}
                  >
                    {request.status}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold">{request.numberOfTrees}</div>
                    <div className="text-sm text-gray-600">Total Trees</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-xl font-bold text-green-600">{request.approvedTrees}</div>
                    <div className="text-sm text-green-600">Approved</div>
                  </div>
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <div className="text-xl font-bold text-red-600">{request.rejectedTrees}</div>
                    <div className="text-sm text-red-600">Rejected</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-xl font-bold text-blue-600">
                      {Math.round((request.approvedTrees / request.numberOfTrees) * 100)}%
                    </div>
                    <div className="text-sm text-blue-600">Success Rate</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Tree Details:</h4>
                  <div className="grid gap-2">
                    {request.treeDetails?.map((tree: any, index: number) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>
                          Tree {index + 1}: {tree.height}ft height, {tree.girth}ft girth
                        </span>
                        <span
                          className={`px-2 py-1 rounded text-xs ${
                            Number.parseFloat(tree.height) > 6 && Number.parseFloat(tree.girth) > 1.5
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                          }`}
                        >
                          {Number.parseFloat(tree.height) > 6 && Number.parseFloat(tree.girth) > 1.5
                            ? "Approved"
                            : "Rejected"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function ProfileTab({ userData, setUserData }: { userData: UserData | null; setUserData: (data: UserData) => void }) {
  const [isEditing, setIsEditing] = useState(false)
  const [editData, setEditData] = useState<UserData>({
    fullName: userData?.fullName || "",
    aadhaarNumber: userData?.aadhaarNumber || "",
    fatherName: userData?.fatherName || "",
    landAddress: userData?.landAddress || "",
    residentialAddress: userData?.residentialAddress || "",
    phoneNumber: userData?.phoneNumber || "",
  })
  const { toast } = useToast()

  const handleEditChange = (field: keyof UserData, value: string) => {
    setEditData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSave = () => {
    // Validate required fields
    if (
      !editData.fullName ||
      !editData.aadhaarNumber ||
      !editData.fatherName ||
      !editData.landAddress ||
      !editData.residentialAddress ||
      !editData.phoneNumber
    ) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    // Validate Aadhaar number (12 digits)
    if (!/^\d{12}$/.test(editData.aadhaarNumber)) {
      toast({
        title: "Error",
        description: "Aadhaar number must be 12 digits",
        variant: "destructive",
      })
      return
    }

    // Validate phone number (10 digits)
    if (!/^\d{10}$/.test(editData.phoneNumber)) {
      toast({
        title: "Error",
        description: "Mobile number must be 10 digits",
        variant: "destructive",
      })
      return
    }

    // Save to localStorage and update state
    localStorage.setItem("sandalwood_user", JSON.stringify(editData))
    setUserData(editData)
    setIsEditing(false)

    toast({
      title: "Success",
      description: "Profile updated successfully!",
    })
  }

  const handleCancel = () => {
    setEditData({
      fullName: userData?.fullName || "",
      aadhaarNumber: userData?.aadhaarNumber || "",
      fatherName: userData?.fatherName || "",
      landAddress: userData?.landAddress || "",
      residentialAddress: userData?.residentialAddress || "",
      phoneNumber: userData?.phoneNumber || "",
    })
    setIsEditing(false)
  }

  if (!userData) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No user data found</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Government Header */}
      <div className="bg-gradient-to-r from-orange-100 to-green-100 p-4 rounded-lg border-l-4 border-orange-500">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">User Profile</h2>
        <p className="text-gray-600">Ministry of Environment, Forest and Climate Change</p>
        <p className="text-sm text-gray-500">Manage your personal information</p>
      </div>

      <Card className="border-2 border-orange-200">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-green-50">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">👤</span>
                Personal Information
              </CardTitle>
              <CardDescription>Your registered details with the government system</CardDescription>
            </div>
            {!isEditing ? (
              <Button
                onClick={() => setIsEditing(true)}
                className="bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700"
              >
                ✏️ Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button
                  onClick={handleSave}
                  className="bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700"
                >
                  💾 Save
                </Button>
                <Button onClick={handleCancel} variant="outline" className="border-orange-200 bg-transparent">
                  ❌ Cancel
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="profileFullName">Full Name</Label>
              {isEditing ? (
                <Input
                  id="profileFullName"
                  value={editData.fullName}
                  onChange={(e) => handleEditChange("fullName", e.target.value)}
                  className="border-orange-200 focus:border-green-500"
                />
              ) : (
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-medium">{userData.fullName}</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="profileAadhaar">Aadhaar Number</Label>
              {isEditing ? (
                <Input
                  id="profileAadhaar"
                  value={editData.aadhaarNumber}
                  onChange={(e) => handleEditChange("aadhaarNumber", e.target.value)}
                  maxLength={12}
                  className="border-orange-200 focus:border-green-500"
                />
              ) : (
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-medium">{userData.aadhaarNumber.replace(/(\d{4})(\d{4})(\d{4})/, "$1 $2 $3")}</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="profileFatherName">Father's Name</Label>
              {isEditing ? (
                <Input
                  id="profileFatherName"
                  value={editData.fatherName}
                  onChange={(e) => handleEditChange("fatherName", e.target.value)}
                  className="border-orange-200 focus:border-green-500"
                />
              ) : (
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-medium">{userData.fatherName}</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="profilePhone">Mobile Number</Label>
              {isEditing ? (
                <Input
                  id="profilePhone"
                  value={editData.phoneNumber}
                  onChange={(e) => handleEditChange("phoneNumber", e.target.value)}
                  maxLength={10}
                  className="border-orange-200 focus:border-green-500"
                />
              ) : (
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-medium">+91 {userData.phoneNumber}</p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="profileLandAddress">Land Address</Label>
              {isEditing ? (
                <Textarea
                  id="profileLandAddress"
                  value={editData.landAddress}
                  onChange={(e) => handleEditChange("landAddress", e.target.value)}
                  className="border-orange-200 focus:border-green-500"
                  rows={3}
                />
              ) : (
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-medium">{userData.landAddress}</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="profileResidentialAddress">Residential Address</Label>
              {isEditing ? (
                <Textarea
                  id="profileResidentialAddress"
                  value={editData.residentialAddress}
                  onChange={(e) => handleEditChange("residentialAddress", e.target.value)}
                  className="border-orange-200 focus:border-green-500"
                  rows={3}
                />
              ) : (
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-medium">{userData.residentialAddress}</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Account Information */}
      <Card className="border-2 border-green-200">
        <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50">
          <CardTitle className="flex items-center gap-2">
            <span className="text-2xl">🔐</span>
            Account Information
          </CardTitle>
          <CardDescription>System and security details</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Account Status</Label>
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <p className="font-medium text-green-800 flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Active & Verified
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Registration Date</Label>
              <div className="p-3 bg-gray-50 rounded-lg border">
                <p className="font-medium">{new Date().toLocaleDateString()}</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Last Login</Label>
              <div className="p-3 bg-gray-50 rounded-lg border">
                <p className="font-medium">{new Date().toLocaleString()}</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>User ID</Label>
              <div className="p-3 bg-gray-50 rounded-lg border">
                <p className="font-medium">STM{userData.aadhaarNumber.slice(-6)}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Security Notice */}
      <Card className="border-2 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <span className="text-2xl">🔒</span>
            <div>
              <h4 className="font-semibold text-blue-800 mb-2">Data Security & Privacy</h4>
              <p className="text-sm text-blue-700 leading-relaxed">
                Your personal information is securely stored and protected under the Digital India initiative. This data
                is used solely for sandalwood tree management and forest conservation purposes. All information is
                encrypted and complies with Government of India data protection guidelines.
              </p>
              <div className="mt-3 flex items-center gap-2 text-xs text-blue-600">
                <span>🛡️ SSL Encrypted</span>
                <span>•</span>
                <span>🇮🇳 Government Compliant</span>
                <span>•</span>
                <span>🔐 Secure Storage</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
