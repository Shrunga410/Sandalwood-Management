"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, X, Send, Bot, User } from "lucide-react"

interface Message {
  id: number
  text: string
  sender: "user" | "bot"
  timestamp: Date
}

interface ChatbotProps {
  activeTab: string
  userData: any
  requests: any[]
}

export function Chatbot({ activeTab, userData, requests }: ChatbotProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your Sandalwood Tree Management assistant. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const getBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase()

    // Contextual responses based on current tab
    if (activeTab === "new-request") {
      if (message.includes("criteria") || message.includes("requirement")) {
        return "For tree approval, your trees must meet these criteria:\n• Height: More than 6 feet\n• Girth: More than 1.5 feet\n\nBoth conditions must be met for approval. You can validate your trees before submitting!"
      }
      if (message.includes("height") || message.includes("tall")) {
        return "Tree height must be greater than 6 feet to meet the approval criteria. Measure from the base to the top of the tree."
      }
      if (message.includes("girth") || message.includes("circumference")) {
        return "Tree girth (circumference) must be greater than 1.5 feet. Measure around the trunk at chest height (about 4.5 feet from ground)."
      }
      if (message.includes("image") || message.includes("photo")) {
        return "You can upload clear photos of each tree. Make sure the image shows the full tree and is well-lit. Supported formats: JPG, PNG, GIF."
      }
    }

    if (activeTab === "track-order") {
      if (message.includes("status") || message.includes("request")) {
        const totalRequests = requests.length
        if (totalRequests === 0) {
          return "You haven't submitted any requests yet. Go to 'New Request' tab to submit your first tree evaluation request!"
        }
        return `You have ${totalRequests} request(s) submitted. The latest request shows ${requests[requests.length - 1]?.status || "Under Review"} status.`
      }
    }

    // General responses
    if (message.includes("hello") || message.includes("hi") || message.includes("hey")) {
      return `Hello ${userData?.fullName || "there"}! Welcome to the Sandalwood Tree Management System. I'm here to help you navigate and understand the system.`
    }

    if (message.includes("help") || message.includes("how")) {
      return "I can help you with:\n• Understanding tree approval criteria\n• Navigating the system\n• Explaining the request process\n• Checking your request status\n• General questions about sandalwood management\n\nWhat would you like to know?"
    }

    if (message.includes("criteria") || message.includes("requirement")) {
      return "Tree approval criteria:\n✅ Height > 6 feet\n✅ Girth > 1.5 feet\n\nBoth conditions must be satisfied. Trees meeting these criteria are considered mature and suitable for management."
    }

    if (message.includes("submit") || message.includes("request")) {
      return "To submit a new request:\n1. Go to 'New Request' tab\n2. Enter number of trees\n3. Fill height & girth for each tree\n4. Upload tree images (optional)\n5. Click 'Validate Trees' to check criteria\n6. Submit your request"
    }

    if (message.includes("track") || message.includes("status")) {
      return "To track your requests:\n1. Go to 'Track Orders' tab\n2. View all submitted requests\n3. Check approval status\n4. See detailed results for each tree\n\nYou can see success rates and individual tree validation results."
    }

    if (message.includes("dashboard")) {
      return "The Dashboard shows:\n📊 Total requests made\n✅ Trees approved (meeting criteria)\n❌ Trees rejected\n\nIt gives you a quick overview of all your submissions and their outcomes."
    }

    if (message.includes("logout") || message.includes("exit")) {
      return "To logout, click the 'Logout' button in the top-right corner of the header. Your data will be saved locally for when you return."
    }

    if (message.includes("data") || message.includes("save")) {
      return "Your data is automatically saved locally in your browser. This includes your profile information and all request details. No internet connection required!"
    }

    if (message.includes("measure") || message.includes("measurement")) {
      return "Measurement tips:\n📏 Height: Measure from ground to tree top\n📐 Girth: Measure circumference at chest height (4.5ft from ground)\n📱 Use a measuring tape for accuracy\n📸 Take photos showing the measurement points"
    }

    if (message.includes("approved") || message.includes("rejected")) {
      return "Tree approval depends on meeting both criteria. Approved trees can proceed with management activities. Rejected trees may need more time to grow or different management approaches."
    }

    if (message.includes("thank")) {
      return "You're welcome! I'm always here to help with your sandalwood tree management needs. Feel free to ask anything else!"
    }

    // Default responses
    const defaultResponses = [
      "I'm here to help with your sandalwood tree management questions. Could you be more specific about what you need help with?",
      "I can assist with tree criteria, submitting requests, tracking orders, or general navigation. What would you like to know?",
      "For specific help, try asking about 'criteria', 'how to submit', 'track status', or 'dashboard'. What interests you?",
    ]

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate bot typing delay
    setTimeout(
      () => {
        const botResponse: Message = {
          id: Date.now() + 1,
          text: getBotResponse(inputValue),
          sender: "bot",
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, botResponse])
        setIsTyping(false)
      },
      1000 + Math.random() * 1000,
    ) // Random delay between 1-2 seconds
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const quickActions = [
    { text: "Tree criteria?", action: "What are the tree approval criteria?" },
    { text: "How to submit?", action: "How do I submit a new request?" },
    { text: "Track my orders", action: "How can I track my request status?" },
    { text: "Need help", action: "I need help navigating the system" },
  ]

  const handleQuickAction = (action: string) => {
    setInputValue(action)
    setTimeout(() => handleSendMessage(), 100)
  }

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 right-4 h-12 w-12 md:h-14 md:w-14 md:bottom-6 md:right-6 rounded-full bg-green-600 hover:bg-green-700 shadow-lg z-50 transition-all duration-200"
          size="icon"
        >
          <MessageCircle className="h-5 w-5 md:h-6 md:w-6" />
          <span className="sr-only">Open chat</span>
        </Button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-96 max-w-[calc(100vw-3rem)] h-[500px] max-h-[calc(100vh-8rem)] shadow-xl z-50 flex flex-col md:w-96 sm:w-80">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-green-600 text-white rounded-t-lg px-3 md:px-6">
            <CardTitle className="text-base md:text-lg font-semibold flex items-center gap-2">
              <Bot className="h-4 w-4 md:h-5 md:w-5" />
              <span className="hidden sm:inline">Sandalwood Assistant</span>
              <span className="sm:hidden">Assistant</span>
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 text-white hover:bg-green-700"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>

          <CardContent className="flex-1 flex flex-col p-0">
            {/* Messages Area */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] sm:max-w-[80%] rounded-lg px-2 sm:px-3 py-2 ${
                        message.sender === "user" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-900"
                      }`}
                    >
                      <div className="flex items-start gap-1 sm:gap-2">
                        {message.sender === "bot" && <Bot className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0" />}
                        {message.sender === "user" && <User className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0" />}
                        <div className="whitespace-pre-wrap text-xs sm:text-sm">{message.text}</div>
                      </div>
                      <div className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 rounded-lg px-3 py-2 flex items-center gap-2">
                      <Bot className="h-4 w-4" />
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div ref={messagesEndRef} />
            </ScrollArea>

            {/* Quick Actions */}
            {messages.length <= 2 && (
              <div className="p-2 sm:p-3 border-t bg-gray-50">
                <div className="text-xs text-gray-600 mb-2">Quick actions:</div>
                <div className="flex flex-wrap gap-1">
                  {quickActions.map((action, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-xs h-6 sm:h-7 bg-transparent px-2"
                      onClick={() => handleQuickAction(action.action)}
                    >
                      {action.text}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Area */}
            <div className="p-2 sm:p-3 border-t">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything..."
                  className="flex-1 text-sm"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim() || isTyping}
                  size="icon"
                  className="bg-green-600 hover:bg-green-700 h-9 w-9 sm:h-10 sm:w-10"
                >
                  <Send className="h-3 w-3 sm:h-4 sm:w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  )
}
